const Stripe = require("stripe");
const { CONFIG } = require("../config");
const { removeRefreshTokenDB, addRefreshTokenDB, verifyRefreshTokenDB } = require("../services/auth.service");
const { signInDB, getAdminUserDB, getActiveTenantsDB, getInActiveTenantsDB, getAllTenantsDB, getOrdersProcessedTodayDB, getSalesVolumeTodayDB, getMRRValueDB, getARRValueDB, getRestaurantsTotalCustomersDB, getSuperAdminTopSellingItemsDB, getSuperAdminSalesVolumeDB, getSuperAdminOrdersProcessedDB, getTenantsDB, addTenantDB, updateTenantDB, getTenantCntByIdDB, getTenantDetailsByIdDB, logoutAllUsersOfTenantDB, deleteTenantDB, getTenantsDataByStatusDB, getTenantSubscriptionHistoryDB, getTenantTotalUsersDB, getTenantDetailsDB, getTenantStoreDetailsDB, upsertGatewayDB, getGatewayDB, updateGatewayStatusDB, getAllPaymentGatewaysDB, activatePaymentGatewayDB, updateGoogleAuthConfigDB, getGoogleAuthConfigDB } = require("../services/superadmin.service")
const { generateAccessToken, generateRefreshToken } = require("../utils/jwt");
const { checkEmailExistsSuperadminDB } = require('../services/auth.service');
const { encryptCredentials, sanitizeCredentialsForUI, decryptCredentials } = require("../utils/encryptCredentials");
const { validateCloudStorageCredentials, normalizeCloudStorageCredentials } = require("../utils/imageStorage");
const { upsertSuperAdminImageStorageConfigDB, getSuperAdminImageStorageConfigDB } = require("../services/image_storage.service");


exports.signIn = async (req, res) => {
    try {

        const username = req.body.username;
        const password = req.body.password;

        if (!(username && password)) {
            return res.status(400).json({
                success: false,
                message: req.__("please_provide_required_details") // Translate message
            });
        }

        const result = await signInDB(username, password);

        if (result) {
            // set cookie
            const cookieOptions = {
                expires: new Date(Date.now() + parseInt(CONFIG.COOKIE_EXPIRY)),
                httpOnly: true,
                domain: CONFIG.FRONTEND_DOMAIN_COOKIE,
                sameSite: false,
                secure: process.env.NODE_ENV == "production",
                path: "/"
            };

            const refreshTokenExpiry = new Date(Date.now() + parseInt(CONFIG.COOKIE_EXPIRY_REFRESH));
            const cookieRefreshTokenOptions = {
                expires: refreshTokenExpiry,
                httpOnly: true,
                domain: CONFIG.FRONTEND_DOMAIN_COOKIE,
                sameSite: false,
                secure: process.env.NODE_ENV == "production",
                path: "/"
            };

            result.password = undefined;

            const payload = {
                username: result.email,
                name: result.name,
                role: "superadmin",
            }
            const accessToken = generateAccessToken(payload);
            const refreshToken = generateRefreshToken(payload);

            res.cookie('accessToken', accessToken, cookieOptions);
            res.cookie('refreshToken', refreshToken, cookieRefreshTokenOptions);
            res.cookie('restroprosaas__authenticated', true, {
                expires: new Date(Date.now() + parseInt(CONFIG.COOKIE_EXPIRY_REFRESH)),
                domain: CONFIG.FRONTEND_DOMAIN_COOKIE,
                sameSite: false,
                secure: process.env.NODE_ENV == "production",
                path: "/"
            })

            // set refresh token in DB.
            const deviceDetails = req.useragent;

            const deviceIP = req.connection.remoteAddress;
            const deviceName = `${deviceDetails.platform}\nBrowser: ${deviceDetails.browser}`;
            const deviceLocation = null;
            await addRefreshTokenDB(username, refreshToken, refreshTokenExpiry, deviceIP, deviceName, deviceLocation, null);

            return res.status(200).json({
                success: true,
                message: req.__("login_successful"), // Translate message
                accessToken,
                user: payload
            })

        } else {
            return res.status(401).json({
                success: false,
                message: req.__("email_or_password_invalid") // Translate message
            });
        }


    } catch (error) {
        console.error(error);
        return res.status(500).json({
            success: false,
            message: req.__("facing_issues_try_later") // Translate message
        });
    }
}
exports.signOut = async (req, res) => {
    try {
        const user = req.user;
        const refreshToken = req.cookies.refreshToken;

        const cookieOptions = {
            expires: new Date(Date.now()),
            httpOnly: true,
            domain: CONFIG.FRONTEND_DOMAIN_COOKIE,
            sameSite: false,
            secure: process.env.NODE_ENV == "production",
            path: "/"
        };

        res.clearCookie('accessToken', cookieOptions);
        res.clearCookie('refreshToken', cookieOptions);
        res.clearCookie('restroprosaas__authenticated', {
            expires: new Date(Date.now()),
            domain: CONFIG.FRONTEND_DOMAIN_COOKIE,
            sameSite: false,
            secure: process.env.NODE_ENV == "production",
            path: "/"
        });

        // remove refreshToken in DB.
        await removeRefreshTokenDB(user.username, refreshToken);

        return res.status(200).json({
            success: true,
            message: req.__("logout_successful") // Translate message
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            success: false,
            message: req.__("something_went_wrong_try_later") // Translate message
        });
    }
}

exports.getNewAccessToken = async (req, res) => {
    try {
        const user = req.user;
        const refreshToken = req.cookies.refreshToken;

        // verify the refresh token with the DB
        const isExist = await verifyRefreshTokenDB(refreshToken);

        if (isExist) {
            // generate new access token
            // set cookie
            const cookieOptions = {
                expires: new Date(Date.now() + parseInt(CONFIG.COOKIE_EXPIRY)),
                httpOnly: true,
                domain: CONFIG.FRONTEND_DOMAIN_COOKIE,
                sameSite: false,
                secure: process.env.NODE_ENV == "production",
                path: "/"
            };
            const u = await getAdminUserDB(user.username);
            const payload = {
                username: u.email,
                name: u.name,
                role: "superadmin",
            }
            const accessToken = generateAccessToken(payload);

            res.cookie('accessToken', accessToken, cookieOptions);

            return res.status(200).json({
                success: true,
                message: req.__("new_token_created_successfully"), // Translate message
                accessToken
            });
        } else {
            res.clearCookie('accessToken', {
                expires: new Date(Date.now()),
                httpOnly: true,
                domain: CONFIG.FRONTEND_DOMAIN_COOKIE,
                sameSite: false,
                secure: process.env.NODE_ENV == "production",
                path: "/"
            });
            res.clearCookie('refreshToken', {
                expires: new Date(Date.now()),
                httpOnly: true,
                domain: CONFIG.FRONTEND_DOMAIN_COOKIE,
                sameSite: false,
                secure: process.env.NODE_ENV == "production",
                path: "/"
            });
            res.clearCookie('restroprosaas__authenticated', {
                expires: new Date(Date.now()),
                domain: CONFIG.FRONTEND_DOMAIN_COOKIE,
                sameSite: false,
                secure: process.env.NODE_ENV == "production",
                path: "/"
            });
            return res.status(401).json({
                success: false,
                loginNeeded: true,
                message: req.__("login_again_to_access") // Translate message
            });
        }

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            success: false,
            message: req.__("something_went_wrong_try_later") // Translate message
        });
    }
};

exports.getTenants = async (req, res) => {
    try {
        const { page, perPage, search, status, type, from, to } = req.query;

        // if (!type) {
        //     return res.status(400).json({
        //       success: false,
        //       message: req.__("please_provide_required_details") // Translate message
        //     });
        //   }

        if (type == "custom") {
            if (!(from && to)) {
                return res.status(400).json({
                    success: false,
                    message: req.__("provide_from_to_dates") // Translate message
                });
            }
        }

        const result = await getTenantsDB(page, perPage, search, status, type, from, to);

        return res.status(200).json(result);
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            success: false,
            message: req.__("something_went_wrong_try_later") // Translate message
        });
    }
}

exports.getSuperAdminTenantsCntData = async (req, res) => {
    try {

        const [activeTenants, inactiveTenants, allTenants] = await Promise.all([
            getActiveTenantsDB(),
            getInActiveTenantsDB(),
            getAllTenantsDB(),
        ]);

        return res.status(200).json({
            activeTenants, inactiveTenants, allTenants
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            success: false,
            message: req.__("something_went_wrong_try_later") // Translate message
        });
    }
}

exports.getSuperAdminDashboardData = async (req, res) => {
    try {

        const [activeTenants, ordersProcessedToday, salesVolumeToday, mrr, arr] = await Promise.all([
            getActiveTenantsDB(),
            getOrdersProcessedTodayDB(),
            getSalesVolumeTodayDB(),
            getMRRValueDB(),
            getARRValueDB()
        ]);

        return res.status(200).json({
            activeTenants, ordersProcessedToday, salesVolumeToday, mrr, arr
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            success: false,
            message: req.__("something_went_wrong_try_later") // Translate message
        });
    }
};

exports.addTenant = async (req, res) => {
    try {
        const { name, email, password, isActive } = req.body;
        if (!name || !email || !password) {
            return res.status(400).json({
                message: req.__("please_provide_required_details") // Translate message
            });
        }

        const isAdmin = 1;

        const tenantData = await addTenantDB({ name, email, password, isAdmin, isActive });

        return res.status(200).json({ message: req.__("tenant_added_successfully"), tenant: tenantData }); // Translate message
    } catch (error) {
        console.error("Error adding tenant:", error);

        if (error == "User already exist! Try Different Email!") {
            return res.status(409).json({ message: req.__("user_already_exist_try_different_email") }); // Translate message
        }

        return res.status(500).json({ message: req.__("error_adding_tenant") }); // Translate message
    }
};


exports.updateTenant = async (req, res) => {
    try {
        const tenantId = req.params.id;
        const { name, email, isActive } = req.body;

        if (!tenantId) {
            return res.status(400).json({ message: req.__("invalid_tenant") }); // Translate message
        }
        if (!name || !email || isActive === undefined) {
            return res.status(400).json({ message: req.__("missing_required_fields") }); // Translate message
        }

        const tenantCnt = await getTenantCntByIdDB(tenantId);

        if (tenantCnt != 1) {
            return res.status(404).json({ message: req.__("tenant_not_found") }); // Translate message
        }

        const currentTenant = await getTenantDetailsByIdDB(tenantId);

        if (currentTenant.username !== email) {
            // check if email exists
            const isEmailExists = await checkEmailExistsSuperadminDB(email, tenantId);

            if (isEmailExists) {
                return res.status(400).json({
                    success: false,
                    message: req.__("account_exists_try_login") // Translate message
                });
            }
        }

        await updateTenantDB(tenantId, name, email, isActive, currentTenant.username);

        if (currentTenant.username !== email || (isActive == 0 && currentTenant.is_active == 1)) {
            await logoutAllUsersOfTenantDB(tenantId);
        }

        return res.status(200).json({ message: req.__("tenant_updated_successfully") }); // Translate message
    } catch (error) {
        console.error('Error updating tenant:', error);
        return res.status(500).json({ message: req.__("error_updating_tenant") }); // Translate message
    }
};

exports.deleteTenant = async (req, res) => {
    try {
        const tenantId = req.params.id;

        if (!tenantId) {
            return res.status(400).json({ message: req.__("invalid_tenant") }); // Translate message
        }

        const tenantCnt = await getTenantCntByIdDB(tenantId);

        if (tenantCnt != 1) {
            return res.status(404).json({ message: req.__("tenant_not_found") }); // Translate message
        }

        await deleteTenantDB(tenantId);

        return res.status(200).json({
            success: true,
            message: req.__("tenant_deleted_successfully") // Translate message
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            success: false,
            message: req.__("something_went_wrong_try_later") // Translate message
        });
    }
}

exports.getTenantsDataByStatus = async (req, res) => {
    try {
        const status = req.params.status;

        if (status != 'active' && status != 'inactive' && status != 'all') {
            return res.status(400).json({
                success: false,
                message: req.__("invalid_status_try_again_later") // Translate message
            });
        }

        let data;

        if (status == 'active') {
            data = await getTenantsDataByStatusDB(1);
        } else if (status == 'inactive') {
            data = await getTenantsDataByStatusDB(0);
        } else if (status == 'all') {
            data = await getTenantsDataByStatusDB(null);

        }

        return res.status(200).json(data);
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            success: false,
            message: req.__("something_went_wrong_try_later") // Translate message
        });
    }
}

exports.getTenantSubscriptionHistory = async (req, res) => {
    try {
        const tenantId = req.params.id;

        const subscriptionHistory = await getTenantSubscriptionHistoryDB(tenantId);

        // tenant info
        const tenantDetails = await getTenantDetailsDB(tenantId);

        // store details
        const storeDetails = await getTenantStoreDetailsDB(tenantId);

        // tenant users
        const tenantTotalUsers = await getTenantTotalUsersDB(tenantId);

        return res.status(200).json({
            tenantInfo: tenantDetails,
            storeDetails: storeDetails,
            totalUsers: tenantTotalUsers,
            subscriptionHistory: subscriptionHistory
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            success: false,
            message: req.__("something_went_wrong_try_later") // Translate message
        });
    }
}

exports.getSuperAdminReportsData = async (req, res) => {
    try {
        const from = req.query.from || null;
        const to = req.query.to || null;
        const type = req.query.type;

        if (!type) {
            return res.status(400).json({
                success: false,
                message: req.__("please_provide_required_details") // Translate message
            });
        }

        if (type == 'custom') {
            if (!(from && to)) {
                return res.status(400).json({
                    success: false,
                    message: req.__("provide_from_to_dates") // Translate message
                });
            }
        }

        const [activeTenants, mrr, arr, totalCustomers, topSellingItems, salesVolume, ordersProcessed] = await Promise.all([
            getActiveTenantsDB(),
            getMRRValueDB(),
            getARRValueDB(),
            getRestaurantsTotalCustomersDB(),
            getSuperAdminTopSellingItemsDB(type, from, to),
            getSuperAdminSalesVolumeDB(type, from, to),
            getSuperAdminOrdersProcessedDB(type, from, to)
        ]);

        return res.status(200).json({
            activeTenants, mrr, arr, totalCustomers, topSellingItems,
            salesVolume, ordersProcessed
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            success: false,
            message: req.__("something_went_wrong_try_later") // Translate message
        });
    }
};

// payment-gateways
exports.updateGatewayCredentials = async (req, res) => {
    try {
        const { gateway_name, credentials } = req.body;

        if (!gateway_name || !credentials || typeof credentials !== 'object') {
            return res.status(400).json({ message: req.__("invalid_payload") });
        }

        // validate stripe key
        if (gateway_name === "stripe" && credentials.secret_key) {
            try {
                const stripe = new Stripe(credentials?.secret_key);
                await stripe.accounts.retrieve(); // validation call
            } catch {
                return res.status(400).json({ message: "Invalid Stripe API key" });
            }
        }

         // 2️⃣ Get existing encrypted credentials
        const existing = await getGatewayDB(gateway_name);

        const existingCredentials = existing?.credentials || {};

        console.log("Existing credentials:", existing);
        console.log("new credentials:", credentials);

        // 3️⃣ Encrypt only updated fields
        const encryptedUpdates = encryptCredentials(credentials);

        // 4️⃣ Merge (THIS IS THE KEY PART)
        const finalCredentials = {
          ...(existingCredentials || {}),
          ...encryptedUpdates
        };

        await upsertGatewayDB(gateway_name, finalCredentials);

        return res.json({ message: req.__("payment_gateway_saved_successfully") });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            success: false,
            message: req.__("something_went_wrong_try_later") // Translate message
        });
    }
};

exports.updateGatewayStatus = async (req, res) => {
    try {
        const { name, status } = req.body;
        await updateGatewayStatusDB(name, status);
        return res.json({ message: req.__("payment_gateway_status_updated_successfully") });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            success: false,
            message: req.__("something_went_wrong_try_later") // Translate message
        });
    }
};

exports.getGatewayDetails = async (req, res) => {
    try {
        const name = req.params.name;
        const row = await getGatewayDB(name);
        return res.json({
          gateway_name: row.gateway_name,
          status: row.status,
          credentials: sanitizeCredentialsForUI(row.credentials)
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            success: false,
            message: req.__("something_went_wrong_try_later") // Translate message
        });
    }
};

exports.activatePaymentGateway = async (req, res) => {
    try {
        const result = await activatePaymentGatewayDB();
        return res.status(200).json(result);
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: req.__("something_went_wrong_try_later") }); // Translate message
    }
};

exports.getAllPaymentGateways = async (req, res) => {
    try {
        const data = await getAllPaymentGatewaysDB();
        
        const sanitized = data.map(row => ({
          id: row.id,
          gateway_name: row.gateway_name,
          status: row.status,
          created_at: row.created_at,
          credentials: sanitizeCredentialsForUI(row.credentials)
        }));

        return res.json(sanitized);
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            success: false,
            message: req.__("something_went_wrong_try_later") // Translate message
        });
    }
};

// ── Global Image Storage Config (SuperAdmin) ────────────────────────────────

exports.getGlobalImageStorageConfig = async (req, res) => {
    try {
        const config = await getSuperAdminImageStorageConfigDB();

        if (!config) {
            return res.status(200).json({
                provider_name: "local",
                status: 0,
                credentials: null,
                mode: "local",
                credentials_configured: false
            });
        }

        const sanitizedCreds = config.credentials
            ? {
                ...sanitizeCredentialsForUI(config.credentials),
                public_url: config.credentials.public_url || null
            }
            : null;

        return res.status(200).json({
            provider_name: config.provider_name,
            status: config.status,
            credentials: sanitizedCreds,
            mode: config.provider_name !== "local" && config.status === 1 ? "cloud" : "local",
            credentials_configured: Boolean(config.credentials)
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            success: false,
            message: req.__("something_went_wrong_try_later")
        });
    }
};

exports.saveGlobalImageStorageConfig = async (req, res) => {
    try {
        const { provider_name, credentials = {}, status, migrationAcknowledged } = req.body;

        if (!provider_name) {
            return res.status(400).json({
                success: false,
                message: req.__("invalid_payload") || "Provider name is required"
            });
        }

        if ((provider_name !== "s3" && provider_name !== "local") || typeof credentials !== "object") {
            return res.status(400).json({
                success: false,
                message: "Invalid image storage configuration"
            });
        }

        const existing = await getSuperAdminImageStorageConfigDB();
        const currentMode = existing?.provider_name !== "local" && existing?.status === 1 ? "cloud" : "local";
        const targetMode = provider_name === "s3" && status ? "cloud" : "local";

        if (currentMode !== targetMode && migrationAcknowledged !== true) {
            return res.status(400).json({
                success: false,
                message: "Confirm that existing images have been migrated before changing storage location."
            });
        }

        if (targetMode === "cloud") {
            const existingCredentials = existing?.credentials || {};

            const decryptedExisting = decryptCredentials(existingCredentials);
            
            const fullPlaintextCredentials = normalizeCloudStorageCredentials({
                ...decryptedExisting,
                ...(existingCredentials.public_url ? { public_url: existingCredentials.public_url } : {}),
                ...credentials
            });

            const validationResult = await validateCloudStorageCredentials(fullPlaintextCredentials);
            if (!validationResult.valid) {
                return res.status(400).json({
                    success: false,
                    message: validationResult.error
                });
            }

            const encryptedCredentials = encryptCredentials(fullPlaintextCredentials);

            const finalCredentials = {
                ...existingCredentials,
                ...encryptedCredentials,
                public_url: fullPlaintextCredentials.public_url
            };

            await upsertSuperAdminImageStorageConfigDB(provider_name, finalCredentials, status ? 1 : 0);
        } else {
            const existingCredentials = existing?.credentials || null;
            await upsertSuperAdminImageStorageConfigDB(provider_name, existingCredentials, 0);
        }

        return res.status(200).json({
            success: true,
            message: "Global image storage configuration saved successfully"
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            success: false,
            message: req.__("something_went_wrong_try_later")
        });
    }
};



exports.updateGoogleAuth = async (req, res) => {
    try {
        const {
            is_active,
            api_key,
            auth_domain,
            project_id,
            storage_bucket,
            messaging_sender_id,
            app_id,
            update_credentials = false,
        } = req.body;
        const shouldUpdateCredentials = update_credentials === true;
        let encryptedConfig = null;

        if (shouldUpdateCredentials) {
            const config = {
                apiKey: api_key?.trim(),
                authDomain: auth_domain?.trim(),
                projectId: project_id?.trim(),
                storageBucket: storage_bucket?.trim(),
                messagingSenderId: messaging_sender_id?.trim(),
                appId: app_id?.trim(),
            };

            if (Object.values(config).some((value) => !value)) {
                return res.status(400).json({
                    success: false,
                    message: "All six Firebase credential values are required to update Google Authentication.",
                });
            }

            encryptedConfig = encryptCredentials(config);
        }

        await updateGoogleAuthConfigDB(
            encryptedConfig,
            is_active === true,
            shouldUpdateCredentials,
        );

        return res.status(200).json({
            success: true,
            message: req.__("google_auth_updated_successfully") || "Google Auth updated successfully",
        });
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            success: false,
            message: req.__("something_went_wrong_try_later"),
        });
    }
};

exports.getGoogleAuth = async (req, res) => {
    try {
        const config = await getGoogleAuthConfigDB();
        const credentials = config?.credentials || {};
        return res.status(200).json({
            is_firebase_service_config: config.is_firebase_service_config,
            configured: Boolean(config),
            status: config?.status || 0,
            configured_fields: {
                api_key: Boolean(credentials.google_api_key),
                auth_domain: Boolean(credentials.google_auth_domain),
                project_id: Boolean(credentials.google_project_id),
                storage_bucket: Boolean(credentials.google_storage_bucket),
                messaging_sender_id: Boolean(credentials.google_messaging_sender_id),
                app_id: Boolean(credentials.google_app_id),
            },
        });
    } catch (error) {
        console.error("Error getting Google Auth config:", error);
        return res.status(500).json({
            success: false,
            message: req.__("something_went_wrong_try_later"),
        });
    }
};
